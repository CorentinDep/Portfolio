
/* ------------CORENTIN-----------*/
function aide() {   // Création de la function aide()
    if (confirm("Avez vous besion d'aide ??")) {   // Si l'utilisateur repond oui alors il affiche le message suivant
        alert("Erreur 404 : \nAucune aide est disponible pour le moment !");
    }  // Sinon ne rien faire
}

function live() {  // Création de la function live()
    if (confirm("Etes vous sur de vouloir quitter la page ?")) { // Si l'utilisateur repond oui alors on affiche un message de au revoir et une redirection est faites vers la page google
        alert("Au revoir et à bientot sur notre site !! ");
        window.location.href = "https://www.google.fr/";
    }  // Sinon ne rien faire
}

function infoCor() { // Création de fonctions qui informe l'utilisateur sur celui qui a cree la page
    alert("Cette page a été creé par Corentin DEPRECQ\nDate de création : 2020\nPage soumise a des droits d'auteurs")
}
function infoLuc() {
    alert("Cette page a été creé par Lucas DUBOURDIEU\nDate de création : 2020\nPage soumise a des droits d'auteurs")
}
function infoGau() {
    alert("Cette page a été creé par Gauthier GUIROLA\nDate de création : 2020\nPage soumise a des droits d'auteurs")
}
function infoKen() {
    alert("Cette page a été creé par Kenzo FAHEM\nDate de création : 2020\nPage soumise a des droits d'auteurs")
}
function infoSim() {
    alert("Cette page a été creé par Simon LAUNAY\nDate de création : 2020\nPage soumise a des droits d'auteurs")
}

function indispo() { // Création d'un fonction pour les pages qui n'existent pas encore
    alert("Erreur 404 : \nCette page est actuellement indisponnible ! \nMais elle le sera très prochainement ! \nMerci de votre patience ...")
}

/* ---------KENZO----------- */
function myFunction() {
    var numRange = this.value; 
        if ( numRange == 1 ) {
            document.getElementById('un').style.fontSize = 90 + 'px';
        }
}


/* -------GAUTHIER-------- */

/*Si l utilisateur appuie sur le bouton Valider	*/
  
function message() {
        
    var mail    = document.getElementById("mail2").value;

       var civilite    = document.getElementById("civilite").value;
    var prenom = document.getElementById("fname").value;
    var nom    = document.getElementById("lname").value;
    var pays    = document.getElementById("pays").value;
    var ville    = document.getElementById("ville").value;
    var codepost    = document.getElementById("codepost").value;
    var adresse    = document.getElementById("adresse").value;
    var numtel    = document.getElementById("numtel").value;




    //	Si l utilisateur ne rempli pas tout les champs on renvoi un message d erreur	


    if (prenom == "" || nom == ""  || pays == ""  || ville == ""  || codepost == ""  || adresse == ""  || numtel == "" 
            || mail == "" || mdp2 == "")
    {
         document.getElementById("errorvide").innerHTML = "!! Tout les champs doivent être saise !!";
    }


    //Si l utilisateur ne donne un numéro de téléphone valide on renvoi un message d erreur	

    else if (numtel < 100000000 || numtel > 999999999)
       {
        document.getElementById("errortel").innerHTML = "!! Numéro de téléphone invalide !!";
    }




   //	Si tout les donées rentrer par l utilisateur sont bonne

    else
    {
        document.getElementById("aff1").innerHTML = civilite + " " + prenom + " " + nom;
        document.getElementById("aff2").innerHTML = mail;

        document.getElementById("aff1.1").innerHTML = civilite + " " + prenom + " " + nom;
        document.getElementById("aff3").innerHTML = adresse;
        document.getElementById("aff4").innerHTML = ville+ ", " + codepost;
        document.getElementById("aff5").innerHTML = pays;
        document.getElementById("aff6").innerHTML = "Tel : " + numtel;


        //	Fait aparraitre les données rentrer par l utilisateur	-->

        document.getElementById("compte1").style.display = "block";
        document.getElementById("compte2").style.display = "block";


        //	Fait disparraitre tout les tableaux et les boutons et les messages d erreur	-->

        document.getElementById("t1").style.display = "none";
        document.getElementById("t2").style.display = "none";
        document.getElementById("b1").style.display = "none";
        document.getElementById("b2").style.display = "none";

        document.getElementById("titre1").style.display = "none";
        document.getElementById("titre2").style.display = "none";

        document.getElementById("error").style.display = "none";
    }

}



//	Si l utilisateur appuie sur le bouton Créer un compte	-->

function table() {

    //	Fait disparraitre : le titre + le premier tableau et le bouton Creer un compte	-->

    document.getElementById("t1").style.display = "none";
    document.getElementById("titre1").style.display = "none";
    document.getElementById("b1").style.display = "none";
    
    
    //	Fait aparraitre : le deuxieme titre et le deuxieme tableau	-->
    
    document.getElementById("titre2").style.display = "block";
    document.getElementById("t2").style.display = "block";
}


        
        